<?php
include('../functions/myfunction.php');

//anti autopath security for admin
//para maisan ma access yung admin tru url
if(isset($_SESSION['auth']))
{
    if($_SESSION['role_as'] != 1)
    {   
        redirect("../index.php","You don't have access this page");
        
    }
}
else
{
    redirect("../login.php","Login to continue");

}


?>